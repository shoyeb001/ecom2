<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <p>Thank you</p>
    <p>from </p>
    <p><?php echo e($details['from']); ?></p>
</body>
</html><?php /**PATH G:\laravel\myshop\resources\views/front/front_pages/mail.blade.php ENDPATH**/ ?>