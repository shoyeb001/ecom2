

<?php $__env->startSection('container'); ?>
<div class="w3l_banner_nav_right">

<div class="w3l_banner_nav_right_banner3">
    <h3>Best Deals For New Products<span class="blink_me"></span></h3>
</div>

<div class="w3ls_w3l_banner_nav_right_grid">
    <h3 style="margin-top: 5rem">Best Deals</h3>

    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

    <div class="w3ls_w3l_banner_nav_right_grid1">
        <h6><?php echo e($item->title); ?></h6>
        <?php
         $product = DB::table('products')->where('status','active')->where('cat_id',$item->id)->take(4)->get();
        ?>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 w3ls_w3l_banner_left">
            <div class="hover14 column">
            <div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
                <div class="agile_top_brand_left_grid_pos">
                    <img src="<?php echo e(asset('front_assets/images/offer.png')); ?>" alt=" " class="img-responsive" />
                </div>
                <div class="agile_top_brand_left_grid1">
                    <figure>
                        <div class="snipcart-item block">
                            <div class="snipcart-thumb">
                                <a href="/product/<?php echo e($list->slug); ?>"><img title=" " alt=" " src="<?php echo e(asset('storage/product/'.$list->photo)); ?>" style="width: 100%"/></a>
                                <p><?php echo e($list->title); ?></p>
                                <h4><?php echo e($list->price); ?></h4>
                                <p><?php echo e(session('msg')); ?></p>
                            </div>
                            <div class="snipcart-details">
                                <form action="/checkout" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <fieldset>
                                        <input type="hidden" name="cmd" value="_cart" />
                                        <input type="hidden" name="p_id" value="<?php echo e($list->id); ?>"/>
                                        <div class="input-group mb-3" style="position: relative">
                                            <label class="input-group-text" for="inputGroupSelect01" style="float: left; margin-right:15px;">Quantity</label>
                                            <select class="form-select" id="inputGroupSelect01" style="float: right" name="add">
                                                <option selected>1</option>

                                                <?php for($i = 2; $i < 11; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <input type="hidden" name="business" value=" " />
                                        <input type="hidden" name="item_name" value="<?php echo e($list->title); ?>" />
                                        <input type="hidden" name="amount" value="<?php echo e($list->price); ?>" />
                                        <input type="hidden" name="currency_code" value="INR" />
                                        <input type="submit" name="submit" value="Add to cart" class="button" />
                                    </fieldset>
                                        
                                </form>
                            </div>
                        </div>
                    </figure>
                </div>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="clearfix"> </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
</div>
<div class="clearfix"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\myshop\resources\views/front/front_pages/bestdeals.blade.php ENDPATH**/ ?>