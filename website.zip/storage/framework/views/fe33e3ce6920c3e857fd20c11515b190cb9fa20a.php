

<?php $__env->startSection('content'); ?>
<div class="header bg-primary pb-6">
    <div class="container-fluid">
      <div class="header-body">
        <div class="row align-items-center py-4">
          <div class="col-lg-6 col-7">
            <h6 class="h2 text-white d-inline-block mb-0">Banner</h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
              <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item">Banner</a></li>
                <li class="breadcrumb-item active" aria-current="page">List</li>
              </ol>
            </nav>
          </div>
          <div class="col-lg-6 col-5 text-right">
            <a href="<?php echo e(url('/admin/banner/add')); ?>" class="btn btn-sm btn-neutral">Add Banner</a>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-neutral">Refresh</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Page content -->
  <div class="container-fluid mt--6">
    <div class="row">
      <div class="col">
        <div class="card">
          <!-- Card header -->
          <div class="card-header border-0">
            <h3 class="mb-0">Light table</h3>
            <p style="font-size: 15px; color:red"><?php echo e(session('msg')); ?></p>
          </div>
          <!-- Light table -->
          <div class="table-responsive" style="overflow-x: hidden">
            <table class="table align-items-center table-flush">
              <thead class="thead-light">
                <tr>
                  <th scope="col" class="sort" data-sort="name">Sl No</th>
                  <th scope="col" class="sort" data-sort="budget">Title</th>
                  <th scope="col" class="sort" data-sort="status">Status</th>
                  <th scope="col">Photos</th>
                  <th scope="col" class="sort" data-sort="completion">Added On</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody class="list">
                 <?php
                   
                   $i=1;
                  
                  ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
                <tr>
                <td class="budget">

                    <?php echo e($i); ?>

                  </td>
                  <td class="budget">
                     <?php echo e($list->title); ?>

                  </td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo e(url('admin/banner/'.$list->status.'/'.$list->id)); ?>"><?php echo e($list->status); ?></a>
                  </td>
                  <td>                      
                        <img alt="Image placeholder" src="<?php echo e(asset('storage/banner/'.$list->photo)); ?>" style="width: 180px">
                  </td>
                  <td>
                    <div class="d-flex align-items-center">
                      <span class="completion mr-2"><?php echo e($list->created_at); ?></span>
                      
                    </div>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-danger" href="<?php echo e(url('admin/banner/delete/'.$list->id)); ?>">Delete</a>
                    <a class="btn btn-sm btn-success" href="<?php echo e(url('admin/banner/edit/'.$list->id)); ?>">Edit</a>
                  </td>
                </tr>
                <?php
                $i = $i+1;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- Card footer -->
          <div class="card-footer py-4">
            
          </div>
        </div>
      </div>
    </div>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\myshop\resources\views/admin/banner/list.blade.php ENDPATH**/ ?>