

<?php $__env->startSection('container'); ?>
<div class="w3l_banner_nav_right">
    <div class="w3l_banner_nav_right_banner4" style="background: url(<?php echo e(asset('storage/categories/'.$category[0]->photo)); ?>);">
        <h3><?php echo e($category[0]->summary); ?><span class="blink_me"></span></h3>
    </div>
    <div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
        <h3><?php echo e($category[0]->title); ?></h3>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w3ls_w3l_banner_nav_right_grid1">
            <div class="col-md-3 top_brand_left" style="margin-bottom:30px;">
            <div class="hover14 column">
                <div class="agile_top_brand_left_grid">
                    <div class="tag"><img src="<?php echo e(asset('front_assets/images/offer.png')); ?>" alt=" " class="img-responsive" /></div>
                    <div class="agile_top_brand_left_grid1">
                        <figure>
                            <div class="snipcart-item block" >
                                <div class="snipcart-thumb">
                                    <a href="/product/<?php echo e($list->slug); ?>"><img title=" " alt=" " src="<?php echo e(asset('storage/product/'.$list->photo)); ?>" style="width: 100%"/></a>		
                                    <p style="height: 43px"><?php echo e($list->title); ?></p>
                                    <h4>INR <?php echo e($list->price); ?></h4>
                                    <p><?php echo e(session('msg')); ?></p>
                                </div>
                                <div class="snipcart-details top_brand_home_details">
                                    <form action="/checkout" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <fieldset>
                                            <input type="hidden" name="cmd" value="_cart" />
                                            <input type="hidden" name="p_id" value="<?php echo e($list->id); ?>"/>
                                            <div class="input-group mb-3" style="position: relative">
                                                <label class="input-group-text" for="inputGroupSelect01" style="float: left; margin-right:15px;">Quantity</label>
                                                <select class="form-select" id="inputGroupSelect01" style="float: right" name="add">
                                                    <option selected>1</option>

                                                    <?php for($i = 2; $i < 11; $i++): ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                            <input type="hidden" name="business" value=" " />
                                            <input type="hidden" name="item_name" value="<?php echo e($list->title); ?>" />
                                            <input type="hidden" name="amount" value="<?php echo e($list->price); ?>" />
                                            <input type="hidden" name="currency_code" value="INR" />
                                            <input type="submit" name="submit" value="Add to cart" class="button" />
                                        </fieldset>
                                            
                                    </form>
                            
                                </div>
                            </div>
                        </figure>
                    </div>
                </div>
            </div>
            </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<div class="clearfix">
    <?php echo csrf_field(); ?>

</div>
</div>
<!-- //banner -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\myshop\resources\views/front/front_pages/category.blade.php ENDPATH**/ ?>