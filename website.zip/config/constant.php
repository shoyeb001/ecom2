<?php

return [

    

    'site_name' => env('SITE_NAME', 'My Shop'),
    'contact_no' =>env('CONTACT_NO','1234569780'),
    'email_add' =>env('EMAIL_ADD','shoyebjio3398@gmail.com')


];
